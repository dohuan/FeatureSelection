clear
clc
close all
tic
option.x_limit = [1 23];     % The limit on the x cordinate will be set here
option.y_limit = [1 9];
option.resolution = 0.2;    % The resulotion of predicted map will be determined here
global system
system.sigma2w = 0.5;       % The measurements noise will be set here
%% Load data and doing pre processings
[location, features, hyper_p] = extract_features('ABS_FFT',32);     % Choices are {ABS_FFT, WAVELET, LOAD,HISTOGRAM}

nt = size(location,1);

%% seperate test set
test_index = 1:10:nt; % we choose 10 percent with jumping 10 step each time
crossvalidation_index = test_index + 1; % we keep 10% cross validation data
test_features = features(test_index,:);
test_location = location(test_index,:);
crossvalidation_features = features(test_index,:);
crossvalidation_location = location(test_index,:);

features([test_index crossvalidation_index],:) = []; % remove test data from trainig dataset
location([test_index crossvalidation_index],:) = []; % remove test data from trainig dataset

%% plot training data set
handle_fig1 = figure('Name','locations:','NumberTitle','off');
axes1 = plot3(location(:,1),location(:,2),location(:,3),'MarkerFaceColor',[1 1 0],'MarkerEdgeColor',[1 0 1],...
    'Marker','o',...
    'LineWidth',2); % plot training sampling positions along with extracted features
% set(axes1,'ZTickLabel',{},'ZTick',zeros(1,0));
zlim([-1000 1000]);
zlim('manual')
xlabel('x direction (m)')
ylabel('y direction (m)')
hdt = datacursormode;
set(hdt,'DisplayStyle','window');
set(hdt,'UpdateFcn',{@labeldtips,features});


nf = size(features,2);

%% Plotting Map
tmp2 = (option.x_limit(1):option.resolution:option.x_limit(2));
tmp1 = (option.y_limit(1):option.resolution:option.y_limit(2));
ng2 = size(tmp2,2);
ng1 = size(tmp1,2);
Predicted_Layer_Map = zeros(ng1,ng2,nf);
Prediction_Layer_Variance = zeros(ng1,ng2,nf);
progressbar('Computing Map layers ...')
% Produce grid points
[x,y] = meshgrid(tmp2,tmp1);
xstar = [reshape(x,[],1),reshape(y,[],1)];
X = location(:,1:2);
for index =1:nf; 
Y = features(:,index);
sigma2w = hyper_p(4,index);
n = size(X,1);
system.Sigma2X = diag([hyper_p(2,index)^2,hyper_p(3,index)^2]);
system.sigma2f = hyper_p(1,index);
KxstarX = CovarianceMatrix(xstar,X); 
KXX = CovarianceMatrix(X);
Kxstarxstar = CovarianceMatrix(xstar);
Lambda = (KXX+sigma2w*eye(n))^(-1);
zhatxstar = KxstarX*Lambda*Y;
sigma2xstar = Kxstarxstar - KxstarX * Lambda * KxstarX';

sigma2xstar = diag(sigma2xstar);
zhatxstar = reshape(zhatxstar,ng1,ng2,[]);
sigma2xstar = reshape(sigma2xstar,ng1,ng2,[]);

Predicted_Layer_Map(:,:,index) = zhatxstar;
Prediction_Layer_Variance(:,:,index) = sigma2xstar;

progressbar(index/nf)
end


plotpredictedmaps(Predicted_Layer_Map,option);
plotpredictedmaps(Prediction_Layer_Variance,option);

save('Layer-Map.mat','Predicted_Layer_Map','Prediction_Layer_Variance');
option.hyperparametrs = hyper_p;

%% Cross validation and feature selection
selected_nf = 1;
selected_featuters = (1:nf);
progressbar('Feature elemination ...')

[~, results(1)] = localizing( ...
                         Predicted_Layer_Map,...                                % required Mapping mean
                         Prediction_Layer_Variance,...                          % required Variance
                         test_features,...                                           % measured feature
                         test_location,...
                         option); 
                     IX = (1:4);
                     option_tmp = option;
                     option_tmp.hyperparametrs = option.hyperparametrs(:,IX);
                     
    [~, results(2)] = localizing( ...
                         Predicted_Layer_Map(:,:,IX),...                                % required Mapping mean
                         Prediction_Layer_Variance(:,:,IX),...                          % required Variance
                         test_features(:,IX),...                                           % measured feature
                         test_location,...
                         option_tmp);                      
     B_Predicted_Layer_Map = Predicted_Layer_Map;
     B_Prediction_Layer_Variance = Prediction_Layer_Variance;
     B_crossvalidation_features = crossvalidation_features;    
     B_test_features = test_features;
     B_option = option;                     
for index1 = 1:(nf-selected_nf)
    if size(Predicted_Layer_Map,3)==16
    [~, results(3)] = localizing( ...
                         Predicted_Layer_Map,...                                % required Mapping mean
                         Prediction_Layer_Variance,...                          % required Variance
                         test_features,...                                           % measured feature
                         test_location,...
                         option);   
    end
    [forward_rank, backward_rank] = ...
        feature_ranking( Predicted_Layer_Map,...
                         Prediction_Layer_Variance, ...
                         crossvalidation_features, ...
                         crossvalidation_location, option);
                     
     [CX(index1), IX] = min(backward_rank);
    
     Predicted_Layer_Map(:,:,IX)          = [];
     Prediction_Layer_Variance(:,:,IX)    = [];
     crossvalidation_features(:,IX)       = [];    
     test_features(:,IX)                  = [];
     option.hyperparametrs(:,IX)          = [];
     [B,IY] = sort(selected_featuters);
     selected_featuters(IY(IX))= 1000 - index1;
     progressbar(index1/(nf-selected_nf))
end
[~,index1]=min(CX);
results(4) = nf - index1;
[~,B] = sort(selected_featuters);
IX = B(1:results(4));
B_option.hyperparametrs = B_option.hyperparametrs(:,IX);
[~, results(5)] = localizing( ...
                         B_Predicted_Layer_Map(:,:,IX),...                                % required Mapping mean
                         B_Prediction_Layer_Variance(:,:,IX),...                          % required Variance
                         B_test_features(:,IX),...                                           % measured feature
                         test_location,...
                         B_option); 

disp(results)
disp('selected features')
disp(selected_featuters);


% nf = selected_nf;
% %% Estimate position of new samplin position using trained map
% [p0, RMS] = localizing( ...
%                      Predicted_Layer_Map,...                                % required Mapping mean
%                      Prediction_Layer_Variance,...                          % required Variance
%                      test_features,...                                           % measured feature
%                      test_location,...
%                      option);    
% 
% for index = 1: size(test_features,1)
%     p1 = p0(index,2);
%     p2 = p0(index,1);
%     
% %     custom_sprintf(p1,p2,test_location(index,2),test_location(index,1));
% 
%     if exist('handle_fig1')
%         figure(handle_fig1);
%         hold on;
%         pause(0.02)
%         plot3(p2,p1,test_location(index,3),...
%             'MarkerFaceColor',[0 1 0],...
%             'MarkerEdgeColor',[1 0 0],...
%             'Marker','o','markersize',10,...
%             'LineWidth',2) %plot estimates localization for the test image
%         plot3(  [p2, test_location(index,1)]',...
%                 [p1, test_location(index,2)]',...
%                 [test_location(index,3), test_location(index,3)]',...
%             'marker','.','color',[1 0 0]);
%     end
% end
% disp('===============================')
% disp(['RMS ERROR: ' num2str(RMS,2)])

toc
