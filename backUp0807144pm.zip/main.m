% ---------- processing data collected from the robotic boat --------------
% run on Alex's car, date: 07-29-14
% -------------------------- Author: Huan N. Do ---------------------------
close all
clc
clear
%%                            DATA PRE-PROCESSING
% ------------------------ reading data -----------------------------------
% fileDir = '.\boat0729145pm\Video Data 7-29-14\BOATAAAM.xls';
% sheetName = 'BOATAAAM';
% range = 'A5:AQ1081';
% [raw,dataName] = readcsv(fileDir,sheetName,range);
fileDir = '.\boat0729145pm\Video Data 7-29-14\BOATAAAL.xls';
sheetName = 'BOATAAAL';
range = 'A4:AQ1081';
[raw,dataName] = readcsv(fileDir,sheetName,range);
% -------------------- declare critical variables here --------------------
timeStamp = raw(:,1);
Lat =  reshape([raw{:,6}],[],1);
Long =  reshape([raw{:,7}],[],1);
% -- info to cut out the ring from dough-nut image
ringInfo.innerRadius = 90;
ringInfo.outerRadius = 180;
ringInfo.center_X = 295;
ringInfo.center_Y = 239;
% -------------------------------------------------------------------------
%nameListRaw = dir('./boat0729145pm/AAAM/');
nameListRaw = dir('./boat0729145pm/AAAL/');
nt = size(timeStamp,1);
% --------------------- delete data with no images ------------------------
lostIndex = [];
index = 1;
% vid = VideoWriter('./SURF_view.avi');
% vid.Quality = 100;
% vid.FrameRate = 20;
% open(vid)
for i=1:nt
    %name_temp = sprintf('./boat0729145pm/AAAM/%d.jpg',timeStamp{i}); 
    name_temp = sprintf('./boat0729145pm/AAAL/%d.jpg',timeStamp{i}); 
    if (exist(name_temp,'file')==0)
        lostIndex = [lostIndex,i];
    else
        img = imread(name_temp);
        % ---------------------- Extract features here --------------------
        %feature(index).histR = imhist(img(:,:,1));
        %unwrap_temp = imageUnwrapper(img,ringInfo);
        figure(1);
        %subplot(2,1,1)
        %imshow(unwrap_temp);
        img_crop = ringExtracter(img,ringInfo); 
        points = detectSURFFeatures(img_crop);
        [features,valid_points] = extractFeatures(img_crop,points);
        surfData(i).feature = features;
        surfData(i).point = valid_points;
        f{i} = valid_points.selectStrongest(10);
        hold on
        plot(f{i},'showOrientation',true);
        hold off
        %BW = im2bw(img_crop,0.7);
        %BW = im2bw(unwrap_temp,0.7);
        %subplot(2,1,2)
        %imshow(BW);
        %M(i) = getframe(figure(1));
        %writeVideo(vid,getframe(gcf));
        % -----------------------------------------------------------------
        index = index+1;
    end
end
%close(vid)
Lat(lostIndex) = [];
Long(lostIndex) = [];
timeStamp(lostIndex) = [];
nt = size(timeStamp,1);

%%                                   MAIN
% ------------------- split train and test data ---------------------------
train_split = 237:246;
test_split = 929:938;

location_train = [Long(train_split) Lat(train_split)];
location_test = [Long(test_split) Lat(test_split)];
train_data = surfData(train_split);
test_data = surfData(test_split);
trainIndex = 1:size(train_split,2);
testIndex = bagofword(train_data,test_data,trainIndex,5);





